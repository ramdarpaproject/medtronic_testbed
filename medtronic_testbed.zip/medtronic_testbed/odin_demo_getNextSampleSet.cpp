#include <iostream>
#include <OdinLib.h>
#include <vector>
#include <chrono>
#include <thread>

using namespace std;
int main(){

	int log_level = 3;
	configureDiagnosticOutput(log_level);


	int major_version, minor_version, build_version;
	getSoftwareVersion(&major_version, &minor_version, &build_version);

	cerr << "Major_version=" << major_version << endl;
	cerr << " Minor_version=" << minor_version << endl;
	cerr << "build_version=" << build_version << endl;

	bool autoConnect=true;
	int writingInterval = 1000;
	int interval = writingInterval;

	int configureEnsSimulatorOptions_status = configureEnsSimulatorOptions(autoConnect, writingInterval);

	cerr << "configureEnsSimulatorOptions_status=" << configureEnsSimulatorOptions_status << endl;


	bool useSimulator = true, showSimulatorGUI = true, useUsb = false;
	int theTimeOut = 2000;		

	int startEnsCommunicationSession_status = startEnsCommunicationSession(useSimulator, showSimulatorGUI, useUsb, theTimeOut);

	
	getFirmwareVersion(&major_version, &minor_version, &build_version);

	cerr << "FIRMWARE VERSION=" << endl;
	cerr << "Major_version=" << major_version << endl;
	cerr << " Minor_version=" << minor_version << endl;
	cerr << "build_version=" << build_version << endl;


	int ns2_status = configureSenseSimulationDataFromNs2File(const_cast<char *>("ns2/256_simple2.ns2"), 0);

	//char * exp_congif_file_name = "d:/src_ens_install/s3_cpp_release/R256X_DefaultConfig.bin";
	//char * exp_congif_file_name = "ns2/R256X_DefaultConfig.bin";

	//int val = configureExperiment(exp_congif_file_name); //IMPORTANT TO GET PROPER HANDLING OF SENSE DATA
	//cerr << "CONFIG EXPERIMENT STATUS=" << val << endl;

	int val = configureExperiment(nullptr); //IMPORTANT TO GET PROPER HANDLING OF SENSE DATA
	cerr << "CONFIG EXPERIMENT STATUS=" << val << endl;

	cerr << "startEnsCommunicationSession_status=" << startEnsCommunicationSession_status << endl;
	int startSensing_status = startSensing();

	/*std::this_thread::sleep_for(std::chrono::milliseconds(1000));*/
	std::this_thread::sleep_for(std::chrono::milliseconds(2*writingInterval));


	int numChannels = 8;
	vector<short> buffer(numChannels,0);
	
	unsigned int sampleTicCount = 0;

	// CHANGE HERE THE NUMBER OF REQUESTED SAMPLE SETS
	unsigned int pref_num_samples = 2;
	
	std::vector<short> single_sample_set_data_buffer(1000, 0);
	std::vector<unsigned int> tic_count_sample_set_data_buffer(1000, 0);

	for (int i = 0; i < 10; ++i) {

		
		
		unsigned int num_samples_long;


				
		num_samples_long = pref_num_samples;
					
		auto getNextSampleSet_status = getNextSampleSet(numChannels, &num_samples_long, &tic_count_sample_set_data_buffer[0], &single_sample_set_data_buffer[0], 0);
		cerr << "getNextSampleSet_status=" << getNextSampleSet_status << " num_samples_long=" << num_samples_long << endl;

		//getNumSamplesAvail_status = getNumSamplesAvail(&num_samples_available);
		//cerr << "after first read num_samples_available=" << num_samples_available << endl;

				

		//for (auto idx = 0; idx < num_samples_long; ++idx) {
		//	cerr << " tic =" << tic_count_sample_set_data_buffer[idx];
		//	for (auto idx_s = 0; idx_s < numChannels; ++idx_s) {

		//		cerr << " buf[" << idx_s << "]=" << single_sample_set_data_buffer[idx*numChannels + idx_s];
		//	}
		//	cerr << endl;
		//}

		for (auto idx = 0; idx < pref_num_samples; ++idx) {
			cerr << "tic=" << tic_count_sample_set_data_buffer[idx] << endl;
		}

		cerr << "buff=";
		for (auto idx = 0; idx < numChannels*pref_num_samples; ++idx) {
			cerr << single_sample_set_data_buffer[idx] <<" , ";
		}
		cerr << endl;

		
			cerr << "SLEEPING FOR " << interval << " ms" << endl;

			std::this_thread::sleep_for(std::chrono::milliseconds(interval));


	}



	int stopSensing_status = stopSensing();
	int stopEnsCommunicationSession_status = stopEnsCommunicationSession();

	int stopEnsSimulator_status = stopEnsSimulator();


}