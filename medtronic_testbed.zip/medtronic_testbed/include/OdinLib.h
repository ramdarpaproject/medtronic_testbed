//
// MEDTRONIC CONFIDENTIAL -- This document is the property of Medtronic, 
// Inc.,and must be accounted for. Information herein is confidential. Do 
// not reproduce it, reveal it to unauthorized persons, or send it outside
// Medtronic without proper authorization.
//
// $Id: OdinLib.h 486217 2016-07-15 00:30:46Z gutzmk2 $
// $HeadURL: http://cad/repo/neuro/odin/tags/OdinLib/OdinLib_v_01_009_00/OdinLib/OdinLib.h $
// $Author: gutzmk2 $
// 

/*! \mainpage OdinLib Index Page
 *
 * \section intro_sec Introduction
 *
 * <p>This is the documentation set for the <b>OdinLib.DLL</b> version <b>1.8.0</b> released
 * on <b>6/28/16</b>.</p>
 *
 * <p>The OdinLib is the DLL that must be used to interface with the ODIN ENS System.</p>
 * 
 * <p>The Odin ENS System supports the DARPA RAM project.  See
 * [DARPA RAM](http://www.darpa.mil/program/restoring-active-memory) for more
 * background information on that project.</p>
 * <p> The purpose of the Odin API is to enable user-written software programs
 * running on the host computer to interface with the Odin external neural
 * stimulator (ENS) to receive sensed data from the ENS and issue stimulation
 * commands to the ENS.  Neither the Odin API nor the Odin ENS will make decisions
 * about what to sense, how to display and interpret the sensed data, or how to
 * apply stimulation to the subject�s electrode contacts.  However, for reasons
 * of safety, the Odin API and the Odin ENS may each impose limits on the
 * stimulation that the Odin ENS will deliver to the subject.  This allow certain
 * risk planning and mitigation activities to be appropriately implemented.</p>
 * <p>The Odin project will deliver a 256 electrode external neurostimulator
 * capable of sensing, stimulation, and distributed closed loop control operation
 * in an Epilepsy Monitoring Unit (EMU) setting.  Odin is a system consisting of
 * an external neural stimulator (ENS) with sense and stimulation capability that
 * communicates through a wired or wireless interface to a computer hosting an API
 * which supports programming of the stimulation and sensing functions, display of
 * the sense data, and external tool support for closed loop operation.  The API
 * for Odin is a data conduit (i.e., bi-directional data port) that transmits data
 * from the ENS to a host computer and transmits stimulation update commands from a
 * host application running on the host computer to the ENS.  The Odin API does not
 * make any decisions about therapy modifications or the data being passed to the
 * host application.</p>
 * <p>This ODIN ENS system will support data sensing from these 256 electrodes
 * within a maxium of 256 data channels of sensing data along with many different
 * stimulation capabilities offered within hardware that supports up to a maximum
 * of 4 different waveform generators working concurrently.</p>
 * 
 * <p>The figure shown below shows all parts of the ENS system as it will be used
 * within a Clinical EEG setting.  This graphic was from a DARPA presentation given
 * in late July 2015 and needs an update from Brandon or Heather (e.g. MATLAB and
 * Mongo should be replaced).
 *
 *    \image html ensSystem.jpg "Figure 1 - A view of the ENS System." 
 *    \image latex ensSystem.eps "Figure 1 - A view of the ENS System." width=10cm
 *
 * <p><b>Important Note:</b> MATLAB, Python, C, and C++ understands char* as a C String,
 * where C# desires this to be an sbyte* which will allow it to process it as a single
 * byte ANSI string and not a double byte Unicode string and used in the C# language.
 * All name arguments will follow the pattern of char* in the C callable interface
 * world, but sbyte* in the C# world.  The function prototypes below will use
 * the "C callable syntax" of char* while the actual C# method will be documented
 * the the sbyte* consistent with the actual implementation needed.</p>
 *
 * \section API_sec OdinLib APIs
 * Here is the complete list of the OdinLib API, including a table of counts first, then
 * a subsection for each of the 5 types of APIs themselves.
 *
 * <table>
 * <caption id="api_counts">API Counts (as of 6/17/16)</caption>
 * <tr><th>Area<th>API Count
 * <tr><td>Experiment Control APIs<td>6
 * <tr><td>Session/Setup APIs<td>8
 * <tr><td>Sensing APIs<td>7
 * <tr><td>Stimulation APIs<td>8
 * <tr><td>Utility APIs<td>18
 * <tr><td>ENS Simulation APIs<td>5
 * <tr><td> **TOTAL** <td> **52** 
 * </table>
 *
 * \subsection api0 Experiment Control APIs
 *    <p>Experiment Control APIs are used to start and stop an experiment as well
 *    as providing methods to control the experiment recording and emergency stop
 *    behavior.  TBD more here about the experiment config file content as it
 *    pertains to additional experiment control.</p>
 *
 *    <p>It is required that Experiments that move from one device to another include
 *    a Host Application restart to establish a pristine reload of the OdinLib.dll
 *    with all defaults restored.  In addition, it would be desirable to reboot the
 *    ODIN PC to acquire an operating system with a default PC configuration that
 *    that will make the next experiment work without any repercussions in performance
 *    from the previous session (e.g. memory fragmentation, processes not ended, etc.)</p>
 *
 *    <p>Experiment Control APIs (need to be used before sensing has been turned on),
 *    all methods listed in this setup section are not allowed when sensing data is
 *    streaming from the device. The first API, startExperiement() should be the first
 *    API used after loading the OdinLib DLL for a specific experiment.</p>
 *    -# [int startExperiment(char *newConstantConfigFilePath);]
 *          (@ref OdinLib.Export.startExperiment)
 *    -# [int stopExperiment();]
 *          (@ref OdinLib.Export.stopExperiment)
 *    -# [int startExperimentRecording(char *recordingSetName);]
 *          (@ref OdinLib.Export.startExperimentRecording)
 *    -# [int stopExperimentRecording();]
 *          (@ref OdinLib.Export.stopExperimentRecording)
 *    -# [int setSafetyMaxAmplitudeLimit(char* stimChannelName, int newAmplitudeInMicroAmps);]
 *          (@ref OdinLib.Export.setSafetyMaxAmplitudeLimit)
 *    -# [int performEmergencyStop();]
 *          (@ref OdinLib.Export.performEmergencyStop)
 *
 * \subsection api1 Session/Setup APIs
 *    <p>Session APIs are used to start and stop a communication session with the Medtronic
 *    ENS system. The system will use a USB connection if the cable is attached, or the
 *    WiFi connection if the cable is not attached.  Session transition and detailed
 *    management will be part of future design documentation, but an initial figure
 *    is provided below that does show some high level state behavior.  This will need
 *    to be updated to include the secure connection process (as this was from Brandon's
 *    e-mail from June 5th, 2015).</p>
 *
 *    \image html ensStateMachine.jpg "Figure 2 - An initial view of the ENS State Machine." 
 *    \image latex ensStateMachine.eps "Figure 2 - An initial view of the ENS State Machine." width=10cm
 *
 *    <p>Setup APIs (need to be used before sensing has been turned on), all methods
 *    listed in this setup section are not allowed when sensing data is streaming
 *    from the device. The Setup APIs are required to "setup" the configuration for a
 *    specific experiment.</p>
 *    -# [int int startEnsCommunicationSession(bool useSimulator, bool showSimulatorGUI, bool useUsb, int theTimeOut);]
 *          (@ref OdinLib.Export.startEnsCommunicationSession)
 *    -# [int stopEnsCommunicationSession();]
 *          (@ref OdinLib.Export.stopEnsCommunicationSession)
 *    -# [int configureExperiment(char* configFileName);]
 *          (@ref OdinLib.Export.configureExperiment)
 *    -# [int configureSense(int samplesPerPacket, int dataRate);]
 *          (@ref OdinLib.Export.configureSense)
 *    -# [int setWaveformName(char* waveformName, int* ampInMicroAmp, int* pwInMicroseconds, int* pulseFreqInHertz, int* numPulses, int* burstFreqInMilliHertz);]
 *          (@ref OdinLib.Export.setWaveformName)
 *    -# [int assignWaveformToChannel(char* waveformName, char* stimChannelName);]
 *          (@ref OdinLib.Export.assignWaveformToChannel)
 *    -# [int setEmergencyStopKey(int newKeyCode, int newKeyModifiers);]
 *          (@ref OdinLib.Export.setEmergencyStopKey)
 *    -# [int setMaximumPulseWidth(int maxPwInMicroSec);]
 *          (@ref OdinLib.Export.setMaximumPulseWidth)
 * \subsection api2 Sensing APIs
 *    <p>These are the APIs required to configure the sensing environment including
 *    starting and stopping as well as sensing sample data retrieval.
 *    The startSensing() API will start the data streaming based on the setup
 *    which was configured within the Setup APIs.  Additional or alternate
 *    setup can be applied within an experiment by making the call to
 *    stopSensing() followed by the alternate setup followed by another
 *    call to startSensing().  Sensing data will not be gathered within
 *    this short transition time, which is under the control of the
 *    host application code.</p>
 *    -# [int startSensing();]
 *          (@ref OdinLib.Export.startSensing)
 *    -# [int stopSensing();]
 *          (@ref OdinLib.Export.stopSensing)
 *    -# [int getNextSample(int numChannels, short *samples);]
 *          (@ref OdinLib.Export.getNextSample)
 *    -# [int getNextSampleSet(int numChannels, int numSamples, short *samples);]
 *          (@ref OdinLib.Export.getNextSampleSet)
 *    -# [int getNumSamplesAvail(int *numSamplesAvailable);]
 *          (@ref OdinLib.Export.getNumSamplesAvail)
 *    -# [int setFilterValues(int lowPassFilter1Value, int lowPassFilter2Value, int highPassFilterValue);]
 *          (@ref OdinLib.Export.setFilterValues)
 *    -# [int getFilterValues(int *lowPassFilter1Value, int *lowPassFilter2Value, int *highPassFilterValue);]
 *          (@ref OdinLib.Export.getFilterValues)
 * \subsection api3 Stimulation APIs
 *    <p>These are the APIs required to configure the stimulation needed for the
 *    particular experiment.  Many different APIs are included to support a wide range
 *    of stimulation capability.
 *    In addition, the some APIs allow for stimulation to change while an active
 *    stimulation channel is being used.</p>
 *    <p>Stimulation APIs can be used after setup APIs have been called and can
 *    be used before or after sensing data has started.  Note that some APIs
 *    use ENS commands combined into a single communication with the device in
 *    what is called a transaction, if needed, to allow multiple stimulation
 *    APIs to occur as timed by the ENS device.  Multiple stim channels defined
 *    in an array will be tied to a transaction.  The stimulateSetForDuration()
 *    API below relies on the internal transaction mechanism to achieve the
 *    hardware level timing.</p>
 *    -# [int stimulateForDuration(char* stimChannelName, int durationInMs, int delayInMs);]
 *          (@ref OdinLib.Export.stimulateForDuration)
 *    -# [int stimulateForNumBursts(char* stimChannelName, int delayInMs, int numberOfBursts);]
 *          (@ref OdinLib.Export.stimulateForNumBursts)
 *    -# [int stimulateSetForDuration(char** stimChannelNameArray, int* stimChannelOffsetInMsArray, int durationInMs, int delayInMs);]
 *          (@ref OdinLib.Export.stimulateSetForDuration)
 *    -# [int stimulateForOnePulse(char* stimChannelName, int delayInMs);]
 *          (@ref OdinLib.Export.stimulateForOnePulse)
 *    -# [int stopStim(char* stimChannelName);]
 *          (@ref OdinLib.Export.stopStim)
 *    -# [int stopAllStim()]
 *          (@ref OdinLib.Export.stopAllStim)
 *    -# [int changeWaveform(int waveformName, int* newAmpInMicroAmp, int* newPwInMicroseconds, int* newPulseFreqInHertz, int* newNumPulses, int newBurstFreqInMilliHertz);]
 *          (@ref OdinLib.Export.changeWaveform)
 *    -# [int changeWaveformAssignment(char* waveformName, char* stimChannelName);]
 *          (@ref OdinLib.Export.changeWaveformAssignment)
 * \subsection api4 Utility APIs
 *    <p>These are the miscellaneous utility APIs required to provide additional
 *    experiment control and information from the experiment Config File. In
 *    addition, annotations for the recording, ENS component version information,
 *    and diagnostic settings are included here.</p>
 *    <p>These APIs can be used within setup or streaming modes of operation.
 *    The "valid value" set will allow the Penn host developer to get the
 *    entire set of valid values, if interested.  If a value within range
 *    is used, but not part of the valid set, the closest valid value will
 *    used.  Not that some parameters like Pulse Periods and Burst Periods
 *    which are tied to Pulse Frequency and Burst Frequency respectively
 *    interact with each other and may have an additional limitation in
 *    context to how they are used together.  Errors will be returned from
 *    APIs that set waveform data that would have a timing conflict.</p> 
 *    -# [int getValidAmplitudeValues(int arraySize, int *validValues);]
 *          (@ref OdinLib.Export.getValidAmplitudeValues)
 *    -# [int getValidPulseWidthValues(int arraySize, int *validValues);]
 *          (@ref OdinLib.Export.getValidPulseWidthValues)
 *    -# [int getValidPulsePeriods(int arraySize, int *validValues);]
 *          (@ref OdinLib.Export.getValidPulsePeriods)
 *    -# [int getValidBurstPeriods(int arraySize, int *validValues);]
 *          (@ref OdinLib.Export.getValidBurstPeriods)
 *    -# [int configureStimAheadTolerance(int durationInMs);]
 *          (@ref OdinLib.Export.configureStimAheadTolerance)
 *    -# [int numWaveformsAvailable(int *numWaveformsAvailable);]
 *          (@ref OdinLib.Export.numWaveformsAvailable)
 *    -# [int isBusy(char* stimChannelName, int *isBusy);]
 *          (@ref OdinLib.Export.isBusy)
 *    -# [int getOdinTime(long* odinTimePointer);]
 *          (@ref OdinLib.Export.getOdinTime)
 *    -# [int annotate(char* messageString, long odinTime);]
 *          (@ref OdinLib.Export.annotate)
 *    -# [int setOdinWorkingDirectory(char* directoryPathString);]
 *          (@ref OdinLib.Export.setOdinWorkingDirectory)
 *    -# [int getConfigFileVersion(char* configFileVersion);]
 *          (@ref OdinLib.Export.getConfigFileVersion)
 *    -# [int getExperimentId(char* experimentId);]
 *          (@ref OdinLib.Export.getExperimentId)
 *    -# [int getSubjectId(char* subjectId);]
 *          (@ref OdinLib.Export.getSubjectId)
 *    -# [int getSoftwareVersion(int *majorVersion, int *minorVersion, int *buildVersion);]
 *          (@ref OdinLib.Export.getSoftwareVersion)
 *    -# [int getFirmwareVersion(int *majorVersion, int *minorVersion, int *buildVersion);]
 *          (@ref OdinLib.Export.getFirmwareVersion)
 *    -# [int configureDiagnosticOutput(int level);]
 *          (@ref OdinLib.Export.configureDiagnosticOutput)
 *    -# [int getConfigurableConstantValue(char *keyName, char **valueResponse);]
 *          (@ref OdinLib.Export.getConfigurableConstantValue)
 *    -# [char* getReturnValueString(int returnValue);]
 *          (@ref OdinLib.Export.getReturnValueString)
 * \subsection api5 ENS Simulation APIs
 *    These are the APIs to interact with the ENS Simulator process which can be
 *    used instead of a real device to allow for playback of previous experiment data
 *    into the OdinLib and subsequently into the Host Application for additional
 *    experiment related work.
 *    These APIS are only available when using the ENS Simulator and will include an
 *    immediate ERROR return if used after starting a session with the real ENS
 *    device.
 *    -# [int configureEnsPortNumber(int portNumber);]
 *          (@ref OdinLib.Export.configureEnsPortNumber)
 *    -# [int configureEnsSimulatorOptions(bool autoConnect, int writingInterval);]
 *          (@ref OdinLib.Export.configureEnsSimulatorOptions)
 *    -# [int stopEnsSimulator();]
 *          (@ref OdinLib.Export.stopEnsSimulator)
 *    -# [int configureSenseSimulationDataFromNs2File(char* simulatedNs2DataFileName, int allChannelOffset);]
 *          (@ref OdinLib.Export.configureSenseSimulationDataFromNs2File)
 *    -# [int configureSenseSimulationData(char* senseChannelName, int amplitude, int frequency, int bias);]
 *          (@ref OdinLib.Export.configureSenseSimulationData)
 */

/* OdinLib APIs:
 *    See OdinLib Doxygen output for detailed descriptions of the APIs.
 *      <http://cad/repo/neuro/odin/OdinLib/OdinLib/docs/html/index.html>
 */

// TODO:  Code generate this file from some new *.tt file that takes this content
//        directy from the Export.cs file.

// C Callable interfaces.
// TODO:  add from code generation here
// ************************************************************
// Interfaces to be used for 6/28/16 Penn Pre-release.
// This release primarily for sensing data processing only.
// ************************************************************

extern "C"
{
// Session/Setup APIs:
int startEnsCommunicationSession(bool useSimulator, bool showSimulatorGUI, bool useUsb, int theTimeOut);
int stopEnsCommunicationSession();
int configureExperiment(char* configFileName);  // Use null for filename only here for default sensing.
int configureSense(int samplesPerPacket, int dataRate);

// Sensing APIs:
int startSensing();
int stopSensing();
int getNextSample(int numChannels, unsigned* ticCountInMs, short* samples);
int getNextSampleSet(int numChannels, unsigned* numSamples, unsigned* ticCountsInMs, short* samples, unsigned maxBlockingTimeInMs);
int getNumSamplesAvail(int *numSamplesAvailable);

// Utility APIs:
int getSoftwareVersion(int *majorVersion, int *minorVersion, int *buildVersion);
int getFirmwareVersion(int *majorVersion, int *minorVersion, int *buildVersion);
int configureDiagnosticOutput(int level);

// ENS Simulation APIs:
int configureEnsPortNumber(int portNumber);
int configureEnsSimulatorOptions(bool autoConnect, int writingInterval);
int stopEnsSimulator();
int configureSenseSimulationDataFromNs2File(char* simulatedNs2DataFileName, int allChannelOffset);


// ***************************************************************************************************************
// Interfaces not to be used yet.  These can be called, but will most likely return UNIMPLEMENTED_METHOD_ERROR.
// ***************************************************************************************************************
// Experiment Control APIs:
int startExperiment(char *newConstantConfigFilePath);
int stopExperiment();
int startExperimentRecording(char *recordingSetName);
int stopExperimentRecording();
int setSafetyMaxAmplitudeLimit(char* stimChannelName, int newAmplitudeInMicroAmps);
int performEmergencyStop();

// Session/Setup APIs:
int setWaveformName(char* waveformName, int ampInMicroV, int pwInMicroSec, int pulseFreqInHz, int numPulses, int burstFreqInHz);
int assignWaveformToChannel(char* waveformName, char* stimChannelName);
int setEmergencyStopKey(int newKeyCode, int newKeyModifiers);
int setMaximumPulseWidth(int maxPwInMicroSec);

// Sensing APIs:
int setFilterValues(int lowPassFilter1Value, int lowPassFilter2Value, int highPassFilterValue);
int getFilterValues(int *lowPassFilter1Value, int *lowPassFilter2Value, int *highPassFilterValue);

// Stimulation APIs:
int stimulateForDuration(char* stimChannelName, int durationInMs, int delayInMs);
int stimulateForNumBursts(char* stimChannelName, int delayInMs, int numberOfBursts);
int stimulateSetForDuration(char** stimChannelNameArray, int* stimChannelOffsetInMsArray, int durationInMs, int delayInMs);
int stimulateForOnePulse(char* stimChannelName, int delayInMs);
int stopStim(char* stimChannelName);
int stopAllStim();
int changeWaveform(int waveformName, int newAmpInMilliV, int newPwInMicroSec, int newPulseFreqInHz, int newNumPulses, int newBurstFreqInHz);
int changeWaveformAssignment(char* waveformName, char* stimChannelName);

// Utility APIs:
int getValidAmplitudeValues(int arraySize, int *validValues);
int getValidPulseWidthValues(int arraySize, int *validValues);
int getValidPulsePeriods(int arraySize, int *validValues);
int getValidBurstPeriods(int arraySize, int *validValues);
int configureStimAheadTolerance(int durationInMs);
int numWaveformsAvailable(int *numWaveformsAvailable);
int isBusy(char* stimChannelName, int *isBusy);
int getOdinTime(long* odinTimePointer);
int annotate(char* messageString, long odinTime);
int setOdinWorkingDirectory(char* directoryPathString);
int getConfigFileVersion(char* configFileVersion);
int getExperimentId(char* experimentId);
int getSubjectId(char* subjectId);
int getConfigurableConstantValue(char *keyName, char **valueResponse);
char* getReturnValueString(int returnValue);

// ENS Simulation APIs:
int configureSenseSimulationData(char* senseChannelName, int amplitude, int frequency, int bias);
} //extern

// Temporary Hand Edited #defines (until code gen in place):

// For setFilterValues() API and the 3 filter argument3:
#define ODIN_KEEP_DEFAULT -1

// For changeWaveform() API and any of the waveform data arguments:
#define ODIN_KEEP_PREVIOUS -1

// For configureSenseSimulationDataFromFile() API and the fileChannelNum argument:
#define ODIN_USE_ALL_CHANNELS 0

// *******************************
// Error Codes (as of 6/28/16):
// *******************************

// Success codes (codes >= 0)
#define METHOD_SUCCESS                      0
#define METHOD_SUCCESS_NO_MORE_SAMPLES      0
#define METHOD_SUCCESS_MORE_SAMPLES_AVAIL   1
#define UNCONFIRMED_SESSION_STARTED_SUCCESS 2
#define SESSION_STARTED_OK                  0
#define SESSION_ALREADY_STARTED_OK          1

// Specific Codes from Firmware used for special processing in the OdinLib or ServerApp.
// These codes are all 0xFExxxxxx based, software codes are 0xFFxxxxxx based. 
#define COM_ERR_BAD_TRANSACTION_CODE          0xFFEEEE01
#define COM_ERR_INVALID_TRANSACTION_LEN       0xFFEEEE02
#define COM_ERR_UNKNOWN_VER_STATUS_SUBCOMMAND 0xFEEEEE09
#define COM_ERR_NOT_AVAIL_DUE_TO_LOCKOUT      0xFEEEEE1C

// OdinLib Specific Warnings (-1 through -100 reserved):
#define ODINLIB_WARNING_START_CODE              0xFFFFFFFF // -1
#define STIM_CHARGE_DENSITY_LIMIT_EXCEEDED      0xFFFFFFFF // -2
#define STIM_SAFETY_AMPLITUDE_LIMIT_EXCEEDED    0xFFFFFFFE // -3
#define ODINLIB_WARNING_END_CODE                0xFFFFFF9C // -100

// OdinLib Specific Errors (0xFF0xxxxx based):
#define SESSION_STARTED_TIMEOUT                    0xFF000001
#define SESSION_USB_EXCEPTION_OUTSIDE_LOOP         0xFF000002
#define SESSION_USB_EXCEPTION_INSIDE_LOOP          0xFF000003
#define UNIMPLEMENTED_METHOD_ERROR                 0xFF000010
#define METHOD_ERROR_NOT_ALLOWED_IN_STREAMING_MODE 0xFF000011
#define METHOD_ERROR_NOT_IN_STREAMING_MODE         0xFF000012
#define METHOD_EXECUTION_EXCEPTION                 0xFF000013
#define SESSION_NOT_STARTED_ERROR                  0xFF000014
#define SESSION_USB_DEVICE_NOT_FOUND_ERROR         0xFF000015
#define METHOD_SECOND_THREAD_ERROR                 0xFF000016
#define SENSE_CONFIG_NOT_SET_ERROR                 0xFF000017
#define SENSE_CONFIG_BUFFER_TOO_LARGE_ERROR        0xFF000018
#define SENSE_CONFIG_INVALID_DATA_RATE_ERROR       0xFF000019
#define WAVEFORM_NOT_FOUND_ERROR                   0xFF000020
#define EXCEEDS_MAXIMUM_PULSE_WIDTH_ERROR          0xFF000021
#define WAVEFORM_ATTRIBUTE_NOT_FOUND_ERROR         0xFF000022

// ENS Simulator Set:
#define SESSION_ENS_SIM_DATA_FILE_NOT_FOUND     0xFF000100

// ServerApp Specific Errors (0xFF1xxxxx based):
#define SERVER_APP_SESSION_STARTED_TIMEOUT      0xFF100001

// Test Interface Specific Errors (0xFF2xxxxx based):
#define TRIM_FILE_NOT_FOUND                     0xFF200001
#define TRIM_FILE_NOT_CORRECT_SIZE              0xFF200002  // Table v0x0103 is 196 bytes.
#define TRIM_FILE_NOT_CORRECT_TABLE_VERSION     0xFF200003  // Table v_0x01-0x03.
#define TRIM_FILE_NAME_NOT_USABLE               0xFF200004

// Raw Command Processing Specific Errors (0xFF2xxx1x based):
#define CMD_PROCESSING_TIMEOUT_EXPIRED                   0xFF200010  // Common error, used many times in many places.
#define CMD_PROCESSING_UNEXPECTED_CMD_ID                 0xFF200011
#define CMD_PROCESSING_UNEXPECTED_SUB_CMD_ID             0xFF200011
#define CMD_PROCESSING_INVALID_TRANSACTION_LEN           0xFF200013
#define CMD_PROCESSING_INVALID_CMD_PAYLOAD_LENGTH        0xFF200014
#define CMD_PROCESSING_INSUFFICIENT_CMD_RESPONSE_LENGTH  0xFF200015
#define CMD_PROCESSING_INSUFFICIENT_TRAN_RESPONSE_LENGTH 0xFF200016

// State Specific Errors:
#define CMD_NOT_ALLOWED_WHILE_SENSING_IN_PROGRESS        0xFF200020

// Catch all default exception error (add exception stack to this error in string map).
#define UNEXPECTED_EXCEPTION_DETECTED                    0xFF200666

/* Debug APIs: still used in OdinLibTest2c.m */
char *getLastDebugString();
int configureElectrodes(char* name, int electrodeNum);
int getNextSample2(int sampleArraySize, short *samples); // -> does not have sample tic argument.
